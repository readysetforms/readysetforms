# ReadySetForms — CLAUDE.md

## What this app does

ReadySetForms sells document bundles (PDF kits) for home daycare providers — licensing application packs, inspection prep checklists, and CACFP compliance documentation. Products are sold via Stripe payment links; delivery is instant digital delivery.

## Stack

Express.js + EJS + Neon PostgreSQL + Render (single web service)

## Directory map

```
server.js        — Express entry point; route mounts only
lib/             — Shared render context helpers
routes/          — Route groups (leads.js = email capture)
services/        — Outbound integrations (email.js = Postmark)
db/              — Database pool and named query exports (index.js, leads.js)
migrations/      — DDL SQL files (timestamped, run via migrate.js)
views/           — EJS templates (layout.ejs = landing page entry)
  partials/      — Shared template sections (hero, products, free-guide, etc.)
public/css/      — Stylesheets (theme.css = all styles)
public/js/       — Client-side JS (analytics.js)
```

## Database

| Table | What it stores |
|---|---|
| leads | Marketing email captures: email, optional name, source tag, timestamp |

## External integrations

- **Stripe** — Payment links (manual creation via `mcp__stripe__create_payment_link`); payments go to company Stripe account with automatic daily payouts (20% platform fee)
- **Postmark** — Transactional email (free guide delivery after lead capture) via `POSTMARK_API_KEY`
- **Polsia R2** — (future) Document file storage for PDF delivery after purchase

## Recent changes

- 2026-05-27 — Added email capture form (free guide) with POST /api/leads endpoint, leads table, and Postmark transactional email delivery
- 2026-05-26 — Added Stripe payment links for License Application Pack ($39) and Inspection Ready Kit ($29); Buy buttons wired on products page; /thank-you confirmation page added
- 2026-05-26 — Initial Express + EJS landing page with products, proof bar, inspection checklist, and closing CTA