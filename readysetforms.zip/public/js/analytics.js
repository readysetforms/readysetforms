/**
 * GA4 event tracking for ReadySetForms.
 * Page views are automatic (gtag config); this module handles
 * product views, buy button clicks, and scroll depth milestones.
 */

(function () {
  'use strict';

  // GA4 measurement ID injected by server at render time.
  // If absent (local dev without the env var), silently no-op.
  var measurementId = window.GA4_MEASUREMENT_ID;
  if (!measurementId) return;

  // ── Scroll depth tracker ─────────────────────────────────────────
  var milestones = [25, 50, 75, 100];
  var fired = {};

  function trackScroll() {
    var scrollPercent = Math.round(
      (window.scrollY + window.innerHeight) / document.documentElement.scrollHeight * 100
    );
    milestones.forEach(function (milestone) {
      if (scrollPercent >= milestone && !fired[milestone]) {
        fired[milestone] = true;
        gtag('event', 'scroll_depth', {
          scroll_depth: milestone + '%',
          send_to: measurementId
        });
      }
    });
  }

  window.addEventListener('scroll', trackScroll, { passive: true });

  // ── Product view tracker ─────────────────────────────────────────
  // Call this when a product card enters the viewport.
  window.trackProductView = function (itemId, itemName, itemPrice) {
    gtag('event', 'view_item', {
      items: [{
        item_id: itemId,
        item_name: itemName,
        item_category: 'document_bundle',
        price: itemPrice
      }],
      send_to: measurementId
    });
  };

  // ── Buy button click tracker ─────────────────────────────────────
  // Call this on Buy Now click before the Stripe redirect.
  window.trackBuyClick = function (itemId, itemName, itemPrice) {
    gtag('event', 'begin_checkout', {
      items: [{
        item_id: itemId,
        item_name: itemName,
        item_category: 'document_bundle',
        price: itemPrice
      }],
      currency: 'USD',
      value: itemPrice,
      send_to: measurementId
    });
  };

  // ── Intersection Observer for product card views ─────────────────
  var observer = new IntersectionObserver(function (entries) {
    entries.forEach(function (entry) {
      if (entry.isIntersecting) {
        var el = entry.target;
        var itemId = el.getAttribute('data-item-id');
        var itemName = el.getAttribute('data-item-name');
        var itemPrice = parseFloat(el.getAttribute('data-item-price'), 10);
        if (itemId && itemName && !isNaN(itemPrice)) {
          window.trackProductView(itemId, itemName, itemPrice);
          observer.unobserve(el);
        }
      }
    });
  }, { threshold: 0.5 });

  document.querySelectorAll('[data-item-id]').forEach(function (el) {
    observer.observe(el);
  });

  // ── Auto-fire buy clicks on .btn-buy links ────────────────────────
  document.addEventListener('click', function (e) {
    var btn = e.target.closest('.btn-buy');
    if (!btn) return;
    var card = btn.closest('[data-item-id]');
    if (!card) return;
    var itemId = card.getAttribute('data-item-id');
    var itemName = card.getAttribute('data-item-name');
    var itemPrice = parseFloat(card.getAttribute('data-item-price'), 10);
    if (itemId && itemName && !isNaN(itemPrice)) {
      window.trackBuyClick(itemId, itemName, itemPrice);
    }
  });

})();