const express = require('express');
const path = require('path');
const { buildLandingContext } = require('./lib/landing-context');

const app = express();
const port = process.env.PORT || 3000;

// Bootstrap — fail fast if DATABASE_URL is missing
require('./db/index');

app.use(express.json());

// EJS view engine. Templates live in ./views/ (entry point: layout.ejs).
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

// Health check endpoint (required for Render)
// Does NOT query database to allow Neon auto-suspend
app.get('/health', (_req, res) => {
  res.json({ status: 'healthy' });
});

// Serve static files from public folder.
// `index: false` disables auto-serving public/index.html as the directory
// index — `/` always hits the EJS render route below, which is the only
// thing that should ever serve the landing page on this template.
app.use(express.static(path.join(__dirname, 'public'), { index: false }));

// API routes
app.use('/api/leads', require('./routes/leads'));

// Landing page
app.get('/', (_req, res) => {
  res.render('layout', buildLandingContext());
});

// Post-payment confirmation page
app.get('/thank-you', (_req, res) => {
  res.render('thank-you', buildLandingContext());
});

app.listen(port, () => {
  console.log(`Server running on port ${port}`);
});
