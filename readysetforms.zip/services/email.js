/**
 * services/email.js — Outbound transactional email via Postmark.
 * Does NOT own any database operations.
 */

const POSTMARK_URL = 'https://api.postmarkapp.com/email';

/**
 * Send the "5 Docs Every Home Daycare Needs" free guide PDF via Postmark.
 * Content is embedded HTML — the guide lives in the email body.
 * A PDF attachment URL can be added later via the `Attachments` field.
 *
 * @param {string} toEmail - Recipient email address.
 * @param {string|null} toName - Recipient display name (optional).
 * @returns {Promise<object>} Postmark API response body.
 */
async function sendFreeGuideEmail({ toEmail, toName = null }) {
  const postmarkApiKey = process.env.POSTMARK_API_KEY;
  if (!postmarkApiKey) {
    throw new Error('POSTMARK_API_KEY environment variable is not set');
  }

  const firstName = toName ? toName.trim().split(' ')[0] : null;
  const greeting = firstName
    ? `Hi ${firstName},`
    : 'Hi there,';

  const htmlBody = `
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <style>
    body { font-family: 'DM Sans', Arial, sans-serif; background: #F8F5F0; margin: 0; padding: 0; }
    .container { max-width: 560px; margin: 0 auto; padding: 48px 24px; }
    .header { background: #C4622D; padding: 32px; border-radius: 16px 16px 0 0; }
    .header h1 { color: #ffffff; font-size: 24px; margin: 0; font-family: Georgia, serif; }
    .body { background: #ffffff; padding: 32px; border-radius: 0 0 16px 16px; border: 1px solid #D9D3CA; border-top: none; }
    .checklist { list-style: none; padding: 0; margin: 24px 0; }
    .checklist li { display: flex; align-items: flex-start; gap: 10px; margin-bottom: 12px; font-size: 15px; color: #1A1A1A; }
    .check-icon { color: #C4622D; font-weight: bold; flex-shrink: 0; }
    .footer { text-align: center; font-size: 12px; color: #9A9490; margin-top: 32px; }
    p { color: #6B6560; line-height: 1.65; }
  </style>
</head>
<body>
  <div class="container">
    <div class="header">
      <h1>5 Docs Every Home Daycare Needs Before Inspection Day</h1>
    </div>
    <div class="body">
      <p>${greeting}</p>
      <p>Here's your free guide. Print it out and check each item before your next inspection — this is exactly what licensing inspectors look for.</p>
      <ul class="checklist">
        <li><span class="check-icon">&#10003;</span> Current license application (signed &amp; dated)</li>
        <li><span class="check-icon">&#10003;</span> Provider food handler certification or CACFP training record</li>
        <li><span class="check-icon">&#10003;</span> Emergency contact &amp; evacuation plan posted</li>
        <li><span class="check-icon">&#10003;</span> Child health records &amp; immunization schedules on file</li>
        <li><span class="check-icon">&#10003;</span> Daily attendance log (signature-ready template)</li>
      </ul>
      <p>If you're missing any of these, we've built complete fillable kits for exactly this situation. ReadySetForms puts the right documents in your hands before the inspector shows up.</p>
      <p>Questions? Reply to this email anytime — we actually read them.</p>
      <p style="margin-top:24px; font-size:14px; color:#1A1A1A;"><strong>— The ReadySetForms Team</strong></p>
      <div class="footer">
        ReadySetForms &bull; documents@readysetforms.com &bull; You're receiving this because you signed up for the free guide.<br>
        <a href="#">Unsubscribe</a>
      </div>
    </div>
  </div>
</body>
</html>
`;

  const payload = {
    From: 'ReadySetForms <hello@readysetforms.com>',
    To: toEmail,
    Subject: 'Your Free Guide: 5 Docs Every Home Daycare Needs',
    HtmlBody: htmlBody,
    MessageStream: 'outbound',
  };

  const response = await fetch(POSTMARK_URL, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'X-Postmark-Account-Token': postmarkApiKey,
    },
    body: JSON.stringify(payload),
  });

  if (!response.ok) {
    const body = await response.text();
    throw new Error(`Postmark API error ${response.status}: ${body}`);
  }

  return response.json();
}

module.exports = { sendFreeGuideEmail };