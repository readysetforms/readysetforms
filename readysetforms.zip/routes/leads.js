/**
 * routes/leads.js — Email capture and lead management.
 * Handles POST /api/leads which saves a lead and triggers the free guide email.
 */

const express = require('express');
const { createLead } = require('../db/leads');
const { sendFreeGuideEmail } = require('../services/email');

const router = express.Router();

/**
 * POST /api/leads
 * Body: { email: string, name?: string }
 *
 * Saves the lead to the database and sends the free guide via Postmark.
 * Returns 201 on success, 400 on validation failure, 500 on server error.
 */
router.post('/', async (req, res) => {
  const { email, name } = req.body || {};

  if (!email || typeof email !== 'string') {
    return res.status(400).json({ error: 'email is required' });
  }

  const cleanEmail = email.trim();
  if (!cleanEmail.includes('@') || cleanEmail.length > 254) {
    return res.status(400).json({ error: 'invalid email format' });
  }

  try {
    const lead = await createLead({ email: cleanEmail, name: name || null });

    // Send email asynchronously — don't block the response on mail delivery.
    // Fire and log; failures are captured in the catch block's console.error.
    sendFreeGuideEmail({ toEmail: lead.email, toName: lead.name })
      .then((result) => console.log(`[leads] Free guide sent to ${lead.email} — Postmark: ${result.MessageID}`))
      .catch((err) => console.error(`[leads] Postmark error for ${lead.email}: ${err.message}`));

    return res.status(201).json({
      message: 'Lead captured. Check your inbox for the free guide!',
      leadId: lead.id,
    });
  } catch (err) {
    // Duplicate email is the expected error from the unique constraint.
    if (err.code === '23505') {
      return res.status(409).json({ error: 'This email has already signed up.' });
    }
    console.error('[leads] DB error:', err.message);
    return res.status(500).json({ error: 'Internal server error' });
  }
});

module.exports = router;