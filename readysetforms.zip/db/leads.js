/**
 * db/leads.js — Lead capture queries.
 * Does NOT own Postmark email sending — see services/email.js.
 */

const { pool } = require('./index');

/**
 * Insert a new marketing lead.
 * @param {string} email - Required. Valid email address.
 * @param {string|null} name - Optional. First name or full name.
 * @param {string} source - Tracking tag, e.g. 'free-guide'.
 */
async function createLead({ email, name = null, source = 'free-guide' }) {
  const result = await pool.query(
    `INSERT INTO leads (email, name, source)
     VALUES ($1, NULLIF(TRIM($2), ''), $3)
     RETURNING id, email, name, source, created_at`,
    [email.toLowerCase().trim(), name, source]
  );
  return result.rows[0];
}

module.exports = { createLead };