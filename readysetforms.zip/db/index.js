/**
 * db/index.js — Database pool and named query exports.
 * All runtime SQL lives here. Routes import from db/<entity>.js only.
 */

const { Pool } = require('pg');

if (!process.env.DATABASE_URL) {
  throw new Error('DATABASE_URL environment variable is required');
}

const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
  ssl: process.env.DATABASE_URL?.includes('localhost')
    ? false
    : { rejectUnauthorized: false },
});

module.exports = { pool };